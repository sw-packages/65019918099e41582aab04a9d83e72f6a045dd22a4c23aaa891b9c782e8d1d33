
#ifndef ST_GL_API_H
#define ST_GL_API_H

struct st_api *st_gl_api_create(void);

#endif
